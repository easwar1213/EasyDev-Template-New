export default [
  { src: `${process.env.PUBLIC_URL}/img/for_store/dog/1.png` },
  { src: `${process.env.PUBLIC_URL}/img/for_store/dog/2.png` },
  { src: `${process.env.PUBLIC_URL}/img/for_store/dog/3.png` },
  { src: `${process.env.PUBLIC_URL}/img/for_store/dog/4.png` },
  { src: `${process.env.PUBLIC_URL}/img/for_store/dog/5.png` },
];
