export default [
  {
    img: `${process.env.PUBLIC_URL}/img/for_store/vase.png`,
    title: 'Knowledge nay estimable questions repulsive daughters',
    quantity: 1,
    price: 120.00,
    tax: 5.00,
    total: 125.00,
  },
  {
    img: `${process.env.PUBLIC_URL}/img/for_store/pillow_dog.png`,
    title: 'Glass Vas Knowledge nay estimable questions repulsive daughters ',
    quantity: 2,
    price: 60.00,
    tax: 2.50,
    total: 125.00,
  },
  {
    img: `${process.env.PUBLIC_URL}/img/for_store/vase_3.png`,
    title: 'Questions repulsive daughters',
    quantity: 12,
    price: 10.00,
    tax: 1.00,
    total: 121.00,
  },
];
